import { config } from "dotenv";
import { startServer } from "./app/app";

config()
startServer();