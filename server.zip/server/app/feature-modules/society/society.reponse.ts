export const SOCIETY_RESPONSE={
    NOT_FOUND:{
        message:"society not found",
        statusCode:404
    },
    UPDATE_SICCESSFULL:{
        message:"society updated sus=ccesfully",
        statusCode:200
    },
    UPDATE_FAILED:{
        message:"society update filed",
        statusCode:400
    },
    ALREADY_EXISTS:{
        message:"society exists ",
        statusCode:400
    }
}