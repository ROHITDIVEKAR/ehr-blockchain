export interface Iauth {
    email:string;
    password: string
}

