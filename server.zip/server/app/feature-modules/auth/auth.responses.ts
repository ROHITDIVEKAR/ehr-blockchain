export const authResponses={
    INVALID_CREDENTIAL:{
        statusCode:400,
        message:"Invalid credential"
    }
}
