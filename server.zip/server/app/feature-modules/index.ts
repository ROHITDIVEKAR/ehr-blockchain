
import AuthRouter from './auth/auth.routes';

export default {
 
    AuthRouter
}