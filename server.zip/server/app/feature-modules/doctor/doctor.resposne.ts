export const DOCTOR_RESPONSE={
    NOT_FOUND:{
        message:"Doctor not found",
        statusCode:404
    },
    UPDATE_SICCESSFULL:{
        message:"Doctor updated sus=ccesfully",
        statusCode:200
    },
    UPDATE_FAILED:{
        message:"Doctor update filed",
        statusCode:400
    },
    ALREADY_EXISTS:{
        message:"Doctor exists ",
        statusCode:400
    }
}