export interface IInsaurance{
    _id?:string,
    name:string,
    price:string,
}