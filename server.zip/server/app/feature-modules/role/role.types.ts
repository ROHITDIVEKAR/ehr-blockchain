export interface IRole{
    _id?:string
    role:string
}